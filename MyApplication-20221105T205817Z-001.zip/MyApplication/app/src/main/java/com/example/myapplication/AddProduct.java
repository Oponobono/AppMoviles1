package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.myapplication.databinding.ActivityAddProductBinding;
import com.example.myapplication.databinding.ActivityWelcomeUserBinding;

public class AddProduct extends AppCompatActivity {

    private ActivityAddProductBinding addProductBinding;
    DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addProductBinding = ActivityAddProductBinding.inflate(getLayoutInflater());
        View view = addProductBinding.getRoot();
        setContentView(view);
        dbHelper = new DbHelper(this);
    }

    public void addProduct(View addProduct){
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues userData = new ContentValues();
                String reference = addProductBinding.etAddReference.getText().toString();
                String productName = addProductBinding.etAddName.getText().toString();
                String kind = addProductBinding.etAddKind.getText().toString();
                String brand = addProductBinding.etAddBrand.getText().toString();
                String price = addProductBinding.etAddPrice.getText().toString();
                String amount = addProductBinding.etAddCuantity.getText().toString();
                String message ="";

                if (!reference.isEmpty() && !productName.isEmpty() && !kind.isEmpty() && !brand.isEmpty() && !price.isEmpty() && !amount.isEmpty()){
                    userData.put("reference", reference);
                    userData.put("productName", productName);
                    userData.put("kind", kind);
                    userData.put("brand", brand);
                    userData.put("price", price);
                    userData.put("amount", amount);

                    long newProduct = db.insert("products", null, userData);
                    message = "Producto " + newProduct +": "+ productName + " registrado exitosamente";
                    clearFields();
                }else {
                    message ="Por favor ingrese todos los datos";
                }

                Toast.makeText(this, "" + message, Toast.LENGTH_SHORT).show();
    }

    private void clearFields() {
        addProductBinding.etAddReference.setText("");
        addProductBinding.etAddName.setText("");
        addProductBinding.etAddKind.setText("");
        addProductBinding.etAddBrand.setText("");
        addProductBinding.etAddPrice.setText("");
        addProductBinding.etAddCuantity.setText("");
    }

    public void addQuery(View addQuery){
        switch (addQuery.getId()){
            case R.id.btnAddQuery:
                Intent intent = new Intent(this,SearchProduct.class);
                startActivity(intent);
                break;
        }
    }
}
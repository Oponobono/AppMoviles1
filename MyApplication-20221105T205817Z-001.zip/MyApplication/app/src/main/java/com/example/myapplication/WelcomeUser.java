package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.myapplication.databinding.ActivityMainBinding;
import com.example.myapplication.databinding.ActivityRegisterBinding;
import com.example.myapplication.databinding.ActivityWelcomeUserBinding;

public class WelcomeUser extends AppCompatActivity {

    private ActivityWelcomeUserBinding welcomeUserBinding;
    private TextView etWelcomeName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        welcomeUserBinding = ActivityWelcomeUserBinding.inflate(getLayoutInflater());
        View view = welcomeUserBinding.getRoot();
        setContentView(view);

        etWelcomeName = (TextView)findViewById(R.id.etWelcomeName);
        String userName = getIntent().getStringExtra("userName");
        etWelcomeName.setText("¡Bienvenido " + userName + "!");
    }

    public void exit(View exit) {
        switch (exit.getId()){
            case R.id.btnExit:
                Intent intent = new Intent(this,MainActivity.class);
                startActivity(intent);
                break;
        }
    }

    public void addProduct(View exit) {
        switch (exit.getId()){
            case R.id.btnAddProductQuery:
                Intent intent = new Intent(this,AddProduct.class);
                startActivity(intent);
                break;
        }
    }

    public void searchProduct(View exit) {
        switch (exit.getId()){
            case R.id.btnSearchProduct:
                Intent intent = new Intent(this,SearchProduct.class);
                startActivity(intent);
                break;
        }
    }
}


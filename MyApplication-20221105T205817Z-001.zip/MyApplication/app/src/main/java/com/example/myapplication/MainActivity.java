package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding mainBinding;
    DbHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = mainBinding.getRoot();
        setContentView(view);
        dbHelper = new DbHelper(this);
        mainBinding.btnSignIn.setOnClickListener(this::signIn);
        mainBinding.btnSignUp.setOnClickListener(this::register);
        /*
         etEmail = findViewById(R.id.etEmail);
         etPassword = findViewById(R.id.etPassword);
         btnSignIn = findViewById(R.id.btnSignIn);
         btnSignUp = findViewById(R.id.btnSignUp);
        */
    }

    public void signIn(View signIn){
        switch (signIn.getId()){
            case R.id.btnSignIn:
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            String email = mainBinding.etEmail.getText().toString();
            String password = mainBinding.etPassword.getText().toString();
                String query = String.format("SELECT * FROM users WHERE email='%s' and password='%s'", email, password);
                Cursor cursor = db.rawQuery(query, null);
                if (cursor.getCount() > 0) {
                    Toast.makeText(this, "El usuario existe", Toast.LENGTH_SHORT).show();
                    cursor.moveToNext();
                    String nameResult = cursor.getString(1);
                    Intent intent = new Intent(this, WelcomeUser.class);
                    intent.putExtra("userName", nameResult);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Usuario no existe", Toast.LENGTH_SHORT).show();
                }
            break;
        }
    }

    public void register(View register){
        switch (register.getId()){
            case R.id.btnSignUp:
                Intent intent = new Intent(this,RegisterActivity.class);
                startActivity(intent);
                break;
        }
    }
}
package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.myapplication.databinding.ActivitySearchProductBinding;
import com.example.myapplication.databinding.ActivityWelcomeUserBinding;

public class SearchProduct extends AppCompatActivity {

    private ActivitySearchProductBinding searchProductBinding;
    DbHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        searchProductBinding = ActivitySearchProductBinding.inflate(getLayoutInflater());
        View view = searchProductBinding.getRoot();
        setContentView(view);
        dbHelper = new DbHelper(this);
    }

    public void executeSearchProduct(View executeSearchProduct) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                String searchProduct = searchProductBinding.etSearchProduct.getText().toString();
                String query = String.format("SELECT * FROM products WHERE productName='%s' OR reference='%s'", searchProduct,searchProduct);
                Cursor cursor = db.rawQuery(query, null);

                if (cursor.getCount() > 0) {
                    cursor.moveToNext();
                    String productReference = cursor.getString(1);
                    String productName = cursor.getString(2);
                    String productKind = cursor.getString(3);
                    String productBrand = cursor.getString(4);
                    int productPrice = cursor.getInt(5);
                    int productAmount = cursor.getInt(6);
                    searchProductBinding.tvResultReference.setText(productReference);
                    searchProductBinding.tvResultName.setText(productName);
                    searchProductBinding.tvResultKind.setText(productKind);
                    searchProductBinding.tvResultBrand.setText(productBrand);
                    searchProductBinding.tvResultPrice.setText(String.valueOf(productPrice));
                    searchProductBinding.tvResultCuantity.setText(String.valueOf(productAmount));
                } else {
                    Toast.makeText(this, "No hay productos con el nombre especificado", Toast.LENGTH_LONG).show();
                    searchProductBinding.tvResultReference.setText("");
                    searchProductBinding.tvResultName.setText("");
                    searchProductBinding.tvResultKind.setText("");
                    searchProductBinding.tvResultBrand.setText("");
                    searchProductBinding.tvResultPrice.setText("");
                    searchProductBinding.tvResultCuantity.setText("");
                }
    }


    public void addProductQuery(View addProductQuery){
        switch (addProductQuery.getId()){
            case R.id.btnAddProductQuery:
                Intent intent = new Intent(this,AddProduct.class);
                startActivity(intent);
                break;
        }
    }
}
package com.example.myapplication;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.databinding.ActivityRegisterBinding;

public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding registerBinding;
    DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        registerBinding = ActivityRegisterBinding.inflate(getLayoutInflater());
        View view = registerBinding.getRoot();
        setContentView(view);
        dbHelper= new DbHelper(this);
    }

    public void registerUser(View view){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues userData = new ContentValues();
        String name = registerBinding.etNameRegister.getText().toString();
        String identification = registerBinding.etIdRegister.getText().toString();
        String email = registerBinding.etEmailRegister.getText().toString();
        String password = registerBinding.etRegisterPassword.getText().toString();
        String confirmPassword = registerBinding.etConfirmPassword.getText().toString();
        String message = "";

        if (!name.isEmpty() && !identification.isEmpty() && !email.isEmpty() && !password.isEmpty() && !confirmPassword.isEmpty()){
            String query = String.format("SELECT * FROM users WHERE email='%s'",email);
            Cursor cursor = db.rawQuery(query,null);
            if(cursor.getCount()>0) {
                message = "Ya existe una cuenta asociada a este email";
            }else if (password.length()<8){
                message = "La contraseña debe tener mínimo 8 carácteres";
            }else if(!password.equals(confirmPassword)){
                message = "Las contraseñas no coinciden";
            }else {
                userData.put("name",name);
                userData.put("identification", identification);
                userData.put("email", email);
                userData.put("password", password);

                long newUser = db.insert("users",null,userData);
                message = "Usuario " + newUser + " registrado con exito";
            }
        }else{
            message ="Debe ingresar todos los datos";
        }

        Toast.makeText(this, "" + message, Toast.LENGTH_SHORT).show();
    }
}